# GSMaP Bias Correction using Graph Neural Networks

This repository contains a sophisticated deep learning framework for correcting bias in GSMaP (Global Satellite Mapping of Precipitation) satellite rainfall data using Graph Neural Networks (GNNs) combined with advanced temporal modeling techniques.

## ⚠️ Hardware Requirements

**IMPORTANT**: This project requires significant computational resources. The training process was designed to run on **2x NVIDIA H200 GPUs**. Ensure you have adequate GPU memory and computational power before attempting to run the code.

## Overview

The system implements a two-stage spatio-temporal prediction model that:
1. **Stage 1**: Predicts whether precipitation occurs (binary classification)
2. **Stage 2**: Estimates precipitation amount and uncertainty (regression with uncertainty quantification)

The model leverages multiple data sources including ground station measurements and satellite data to provide accurate bias-corrected precipitation estimates.

## Key Features

- **Spatio-Temporal Modeling**: Processes both temporal sequences and spatial relationships between weather stations
- **Graph Neural Networks**: Utilizes advanced GNN architectures for spatial correlation modeling
- **Multi-Modal Data Fusion**: Combines satellite data (GSMaP) with ground station measurements
- **Uncertainty Quantification**: Provides uncertainty estimates using Gaussian Process-inspired heads
- **Ensemble Learning**: Implements model ensemble for improved stability and accuracy
- **Advanced Similarity Metrics**: Uses Dynamic Time Warping (DTW) and correlation-based graph construction

## Architecture Components

### 1. Enhanced Spatial-Temporal Graph Neural Network (STGNN)
- Custom message passing with edge attention mechanisms
- Multi-head temporal attention for time series modeling
- Adaptive spatial relationship learning

### 2. Two-Stage Prediction Framework
- **Binary Classification**: Determines precipitation occurrence
- **Regression**: Predicts precipitation amount with uncertainty bounds

### 3. Graph Construction
The system creates multi-layered graph structures based on:
- **Geographic Distance**: Euclidean distance between stations
- **Temporal Correlation**: Cross-correlation between precipitation time series
- **Dynamic Time Warping**: Temporal similarity between stations
- **Feature Similarity**: Cosine similarity of meteorological features

### 4. Advanced Neural Components
- **MetaKAN**: Meta-learning network for precipitation value prediction
- **GPHead**: Gaussian Process-inspired uncertainty quantification
- **Enhanced Temporal Attention**: Multi-head attention for temporal dependencies

## Installation

```bash
pip install torch torch-geometric pandas numpy matplotlib fastdtw scipy scikit-learn pyarrow tqdm
```

### Required Dependencies
- PyTorch (with CUDA support)
- PyTorch Geometric
- pandas
- numpy
- matplotlib
- fastdtw
- scipy
- scikit-learn
- pyarrow
- tqdm

## Data Requirements

The system expects preprocessed data in Parquet format with the following structure:

### Input Files
1. **Model Input Data** (`model_input_path`): Contains ground station measurements
2. **Satellite Data** (`satellite_data_path`): Contains GSMaP satellite precipitation data

### Required Columns
- **datetime**: Timestamp
- **Station**: Station identifier
- **precipitation**: Target variable (ground truth)
- **GSMap**: Satellite precipitation estimates
- **Meteorological features**: Temperature, humidity, pressure, wind speed, etc.
- **Spatial coordinates**: lat, long

## Usage

### Basic Usage

```python
# Set data paths
model_input_path = "path/to/model_input.parquet"
satellite_data_path = "path/to/satellite_data.parquet"

# Run the main training pipeline
python bias_correction_gsmap.py
```

### Key Parameters

```python
# Model configuration
seq_len = 7           # Temporal sequence length
hidden_dim = 128      # Hidden dimension size
num_layers = 3        # Number of GNN layers
num_epochs = 100      # Training epochs
batch_size = 32       # Batch size
learning_rate = 0.001 # Learning rate
```

## Model Training

The training process involves:

1. **Data Preprocessing**
   - Feature standardization
   - Temporal sequence creation
   - Graph structure construction

2. **Two-Stage Training**
   - Binary classification loss (BCE)
   - Regression loss (MSE)
   - Combined loss optimization

3. **Evaluation Metrics**
   - Binary accuracy
   - Percentage Bias Absolute (PBIASabs)
   - Constraint violation rate
   - Uncertainty calibration

## Evaluation Metrics

- **Binary Accuracy**: Accuracy of precipitation occurrence prediction
- **PBIASabs**: Percentage bias absolute for precipitation amounts
- **Constraint Violations**: Rate of physically impossible predictions (e.g., negative precipitation)
- **Uncertainty Quality**: Calibration of uncertainty estimates

## File Structure

```
├── bias_correction_gsmap.ipynb    # Main Jupyter notebook
├── data/
│   ├── model_input.parquet       # Ground station data
│   └── satellite_data.parquet    # Satellite data
├── models/                       # Saved model checkpoints
├── results/                      # Training results and plots
└── README.md                     # This file
```

## Key Functions

### Data Processing
- `load_processed_data()`: Load and merge input datasets
- `preprocess_features()`: Feature scaling and preprocessing
- `create_spatio_temporal_dataset()`: Create 4D tensor datasets

### Graph Construction
- `create_graph_structure()`: Build multi-modal graph structures
- Dynamic similarity computation using DTW and correlation

### Model Components
- `EnhancedSTGNNLayer`: Core spatial message passing layer
- `EnhancedTemporalAttention`: Multi-head temporal attention
- `EnhancedTwoStageModel`: Complete two-stage prediction model
- `EnsembleModel`: Model ensemble wrapper

### Training & Evaluation
- `train_model()`: Main training loop with dual loss functions
- `evaluate_model()`: Comprehensive model evaluation
- Uncertainty sampling and calibration assessment

## Performance Considerations

- **Memory Usage**: High memory requirements due to spatio-temporal data structure
- **Computational Intensity**: Graph convolutions and attention mechanisms are computationally expensive
- **GPU Acceleration**: Strongly recommended for practical training times
- **Batch Processing**: Implement gradient accumulation for large datasets

## Hardware Recommendations

- **Minimum**: 1x RTX 3090 or equivalent (24GB VRAM)
- **Recommended**: 2x NVIDIA H200 GPUs (as used in development)
- **RAM**: 64GB+ system RAM
- **Storage**: SSD for data loading efficiency

## Citation

If you use this code in your research, please cite:

```bibtex
@article{gsmap_bias_correction,
  title={Advanced Bias Correction for Satellite Precipitation Data using Spatio-Temporal Graph Neural Networks},
  author={[Your Name]},
  journal={[Journal Name]},
  year={2024}
}
```
